// Servidor MCP local para CaribeMart (esqueleto del laboratorio).
// Solo se comunica por stdio: nunca uses console.log aquí, usa console.error.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PEDIDOS_PATH = path.join(__dirname, "pedidos.json");

async function leerPedidos() {
  const texto = await fs.readFile(PEDIDOS_PATH, "utf-8");
  return JSON.parse(texto);
}

async function guardarPedidos(pedidos) {
  await fs.writeFile(PEDIDOS_PATH, JSON.stringify(pedidos, null, 2) + "\n", "utf-8");
}

const server = new McpServer({
  name: "caribemart",
  version: "1.0.0",
});

// Herramienta de ejemplo: consultar un pedido por su numero.
server.tool(
  "consultar_pedido",
  {
    pedidoId: z.number().int().positive().describe("Numero del pedido, por ejemplo 1001"),
  },
  async ({ pedidoId }) => {
    const pedidos = await leerPedidos();
    const pedido = pedidos.find((p) => p.pedidoId === pedidoId);
    if (!pedido) {
      return { content: [{ type: "text", text: "No encontre el pedido " + pedidoId }] };
    }
    const texto = "Pedido " + pedido.pedidoId + " de " + pedido.cliente + ": estado " + pedido.estado + ", total " + pedido.total;
    return { content: [{ type: "text", text: texto }] };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
console.error("Servidor MCP caribemart listo (stdio)");
